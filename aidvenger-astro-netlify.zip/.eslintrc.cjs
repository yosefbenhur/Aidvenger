module.exports = {
  root: true,
  parserOptions: { ecmaVersion: 2023, sourceType: "module" },
  env: { browser: true, es2021: true },
  extends: ["eslint:recommended", "plugin:react/recommended"],
  settings: { react: { version: "18.3" } },
  rules: {
    "react/react-in-jsx-scope": "off"
  }
};
