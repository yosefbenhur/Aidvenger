Place Lighthouse screenshots here after running audits.
